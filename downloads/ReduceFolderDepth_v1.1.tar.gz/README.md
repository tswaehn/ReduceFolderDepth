***ReduceFolderDepth***

This script moves all files of deeper folder structure to
first level of folder structure.

Ok. Understood - but WHY ??

I needed this for my MP3 player - to have all *.mp3 files in a single folder for each artist 
(Without additional subfolders)

*history*

* ver1.1 - release

* ver1.0 - test
